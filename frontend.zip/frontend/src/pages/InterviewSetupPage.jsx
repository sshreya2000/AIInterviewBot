import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import InterviewModeSelector from '../components/InterviewModeSelector';
import assessmentApi from '../api/assessmentApi';

export default function InterviewSetupPage() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const [mode, setMode] = useState('TEXT');
  const [maxQuestions, setMaxQuestions] = useState(10);
  const [loading, setLoading] = useState(false);

  const handleStart = async () => {
    setLoading(true);
    try {
      const res = await assessmentApi.startInterview({
        candidateProfileId: state?.candidateProfileId,
        jobDescriptionId: state?.jobDescriptionId,
        interviewMode: mode,
        preferredLanguage: 'en',
        maxQuestions: Number(maxQuestions),
      });
      toast.success('Interview started!');
      navigate(`/interview/text/${res.data.sessionId}`, {
        state: { maxQuestions: Number(maxQuestions) },
      });
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <nav className="nav">
        <span style={{ fontWeight: 800 }}>🤖 AI Interview Bot</span>
      </nav>
      <div className="container">
        <div className="step-indicator">
          <div className="step step-done">✓</div>
          <div className="step-line" />
          <div className="step step-active">2</div>
          <div className="step-line" />
          <div className="step step-inactive">3</div>
        </div>
        <p className="page-title">Interview Setup</p>
        {state?.candidateName && (
          <div className="card">
            <p><strong>Candidate:</strong> {state.candidateName}</p>
            <p><strong>Role:</strong> {state.roleApplied}</p>
            {state.extractedSkills?.length > 0 && (
              <p style={{ marginTop: 8 }}>
                <strong>Skills detected:</strong>{' '}
                {state.extractedSkills.map((s) => (
                  <span key={s} className="badge badge-blue">{s}</span>
                ))}
              </p>
            )}
          </div>
        )}
        <div className="card">
          <InterviewModeSelector value={mode} onChange={setMode} />
          <label>Number of Questions</label>
          <select value={maxQuestions} onChange={(e) => setMaxQuestions(e.target.value)}>
            {[5, 10, 15, 20].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <button className="btn btn-primary" onClick={handleStart} disabled={loading}>
          {loading ? 'Starting...' : '🚀 Start Interview'}
        </button>
      </div>
    </div>
  );
}
